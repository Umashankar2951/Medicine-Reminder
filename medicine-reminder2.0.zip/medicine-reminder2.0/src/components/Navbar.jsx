import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="navbar">
      <Link to="/" className="brand">💊 Medicine Reminder</Link>
      <div className="nav-links">
        <Link to="/">Dashboard</Link>
        <Link to="/medicines/new">Add Medicine</Link>
      </div>
    </nav>
  );
}
