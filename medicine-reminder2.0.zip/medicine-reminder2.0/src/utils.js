const pad = (n) => String(n).padStart(2, '0');

// Local date as YYYY-MM-DD
export const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

// Local time as HH:MM
export const nowTime = () => {
  const d = new Date();
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

export const isActiveOn = (med, date) => med.startDate <= date && date <= med.endDate;

export const isTaken = (med, date, time) =>
  (med.takenLog || []).some((l) => l.date === date && l.time === time);
