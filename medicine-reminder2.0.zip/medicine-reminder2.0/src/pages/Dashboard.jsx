import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { deleteMedicine, getMedicines, toggleTaken } from '../storage.js';
import { isActiveOn, isTaken, nowTime, todayStr } from '../utils.js';

export default function Dashboard() {
  const [meds, setMeds] = useState(() => getMedicines());
  const [error, setError] = useState('');
  const [today, setToday] = useState(todayStr());
  const [due, setDue] = useState([]); // in-app reminder banners
  const alerted = useRef(new Set());
  const medsRef = useRef([]);

  useEffect(() => {
    medsRef.current = meds;
  }, [meds]);

  // Reminder checker: runs every 20s, fires once per dose per day
  useEffect(() => {
    const check = () => {
      const date = todayStr();
      const time = nowTime();
      setToday((prev) => (prev === date ? prev : date));

      medsRef.current.forEach((m) => {
        if (!isActiveOn(m, date)) return;
        m.times.forEach((t) => {
          const key = `${m._id}|${date}|${t}`;
          if (t === time && !isTaken(m, date, t) && !alerted.current.has(key)) {
            alerted.current.add(key);
            setDue((d) => [...d, { key, name: m.name, dosage: m.dosage, time: t }]);
            if ('Notification' in window && Notification.permission === 'granted') {
              new Notification('Time for your medicine', { body: `${m.name} - ${m.dosage} (${t})` });
            }
          }
        });
      });
    };
    check();
    const timer = setInterval(check, 20000);
    return () => clearInterval(timer);
  }, []);

  const enableNotifications = async () => {
    if (!('Notification' in window)) {
      alert('This browser does not support notifications.');
      return;
    }
    const result = await Notification.requestPermission();
    if (result !== 'granted') alert('Notifications were not enabled. In-app reminders will still appear.');
  };

  const schedule = useMemo(() => {
    const items = [];
    meds.forEach((m) => {
      if (!isActiveOn(m, today)) return;
      m.times.forEach((t) => items.push({ med: m, time: t, taken: isTaken(m, today, t) }));
    });
    return items.sort((a, b) => a.time.localeCompare(b.time));
  }, [meds, today]);

  const handleToggle = (med, time) => {
    try {
      const updated = toggleTaken(med._id, today, time);
      setMeds((list) => list.map((m) => (m._id === med._id ? updated : m)));
      setDue((d) => d.filter((x) => !(x.name === med.name && x.time === time)));
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = (id) => {
    if (!window.confirm('Delete this medicine?')) return;
    try {
      deleteMedicine(id);
      setMeds((list) => list.filter((m) => m._id !== id));
    } catch (err) {
      setError(err.message);
    }
  };

  const statusOf = (m) => {
    if (today < m.startDate) return 'Upcoming';
    if (today > m.endDate) return 'Completed';
    return 'Active';
  };

  return (
    <div>
      {error && <div className="alert error">{error}</div>}

      {due.map((d) => (
        <div className="alert warn" key={d.key}>
          <span>⏰ <strong>{d.time}</strong> — time to take <strong>{d.name}</strong> ({d.dosage})</span>
          <button className="btn small secondary" onClick={() => setDue((x) => x.filter((i) => i.key !== d.key))}>Dismiss</button>
        </div>
      ))}

      <div className="card">
        <div className="between">
          <h2>Today's schedule ({today})</h2>
          <button className="btn small secondary" onClick={enableNotifications}>Enable browser notifications</button>
        </div>
        {schedule.length === 0 ? (
          <p className="muted">No doses scheduled for today.</p>
        ) : (
          <table>
            <thead>
              <tr><th>Time</th><th>Medicine</th><th>Dosage</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {schedule.map((s) => (
                <tr key={`${s.med._id}-${s.time}`}>
                  <td>{s.time}</td>
                  <td>{s.med.name}</td>
                  <td>{s.med.dosage}</td>
                  <td><span className={`badge ${s.taken ? 'green' : 'gray'}`}>{s.taken ? 'Taken' : 'Pending'}</span></td>
                  <td>
                    <button className="btn small" onClick={() => handleToggle(s.med, s.time)}>
                      {s.taken ? 'Undo' : 'Mark taken'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <div className="between">
          <h2>All medicines</h2>
          <Link className="btn small" to="/medicines/new">+ Add medicine</Link>
        </div>
        {meds.length === 0 ? (
          <p className="muted">No medicines yet. Add your first one.</p>
        ) : (
          <div className="scroll">
            <table>
              <thead>
                <tr><th>Name</th><th>Dosage</th><th>Times</th><th>Start</th><th>End</th><th>Status</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {meds.map((m) => (
                  <tr key={m._id}>
                    <td>{m.name}{m.notes ? <div className="muted small-text">{m.notes}</div> : null}</td>
                    <td>{m.dosage}</td>
                    <td>{m.times.join(', ')}</td>
                    <td>{m.startDate}</td>
                    <td>{m.endDate}</td>
                    <td>{statusOf(m)}</td>
                    <td className="actions">
                      <Link className="btn small secondary" to={`/medicines/${m._id}/edit`}>Edit</Link>
                      <button className="btn small danger" onClick={() => remove(m._id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
