import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createMedicine, getMedicine, updateMedicine } from '../storage.js';
import { todayStr } from '../utils.js';

export default function MedicineForm() {
  const { id } = useParams();
  const editing = Boolean(id);
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    dosage: '',
    times: ['08:00'],
    startDate: todayStr(),
    endDate: todayStr(),
    notes: '',
  });
  const [error, setError] = useState('');
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!editing) return;
    const m = getMedicine(id);
    if (!m) {
      setError('Medicine not found');
      setNotFound(true);
      return;
    }
    setForm({
      name: m.name,
      dosage: m.dosage,
      times: m.times,
      startDate: m.startDate,
      endDate: m.endDate,
      notes: m.notes || '',
    });
  }, [id, editing]);

  const set = (field, value) => setForm((f) => ({ ...f, [field]: value }));
  const setTime = (i, value) =>
    setForm((f) => ({ ...f, times: f.times.map((t, idx) => (idx === i ? value : t)) }));
  const addTime = () => setForm((f) => ({ ...f, times: [...f.times, '12:00'] }));
  const removeTime = (i) =>
    setForm((f) => ({ ...f, times: f.times.filter((_, idx) => idx !== i) }));

  const submit = (e) => {
    e.preventDefault();
    setError('');
    if (form.endDate < form.startDate) {
      setError('End date cannot be before start date');
      return;
    }
    if (form.times.some((t) => !t)) {
      setError('Please fill in every time');
      return;
    }
    try {
      if (editing) updateMedicine(id, form);
      else createMedicine(form);
      navigate('/');
    } catch (err) {
      setError(err.message);
    }
  };

  if (notFound) {
    return (
      <div className="card narrow">
        <div className="alert error">{error}</div>
        <button className="btn secondary" onClick={() => navigate('/')}>Back</button>
      </div>
    );
  }

  return (
    <div className="card narrow">
      <h2>{editing ? 'Edit medicine' : 'Add medicine'}</h2>
      {error && <div className="alert error">{error}</div>}
      <form onSubmit={submit}>
        <label>Medicine name</label>
        <input value={form.name} onChange={(e) => set('name', e.target.value)} required />

        <label>Dosage (e.g. 1 tablet, 5 ml, 500 mg)</label>
        <input value={form.dosage} onChange={(e) => set('dosage', e.target.value)} required />

        <label>Time(s) of day</label>
        {form.times.map((t, i) => (
          <div className="row" key={i}>
            <input type="time" value={t} onChange={(e) => setTime(i, e.target.value)} required />
            {form.times.length > 1 && (
              <button type="button" className="btn small danger" onClick={() => removeTime(i)}>Remove</button>
            )}
          </div>
        ))}
        <button type="button" className="btn small secondary" onClick={addTime}>+ Add another time</button>

        <div className="grid2">
          <div>
            <label>Start date</label>
            <input type="date" value={form.startDate} onChange={(e) => set('startDate', e.target.value)} required />
          </div>
          <div>
            <label>End date</label>
            <input type="date" value={form.endDate} min={form.startDate} onChange={(e) => set('endDate', e.target.value)} required />
          </div>
        </div>

        <label>Notes (optional)</label>
        <textarea rows={3} value={form.notes} onChange={(e) => set('notes', e.target.value)} />

        <div className="row">
          <button className="btn">{editing ? 'Update' : 'Save'}</button>
          <button type="button" className="btn secondary" onClick={() => navigate('/')}>Cancel</button>
        </div>
      </form>
    </div>
  );
}
