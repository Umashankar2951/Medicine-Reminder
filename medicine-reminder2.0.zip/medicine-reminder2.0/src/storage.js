// All data is kept in the browser's localStorage under one key.
const KEY = 'medicine-reminder:medicines';

const newId = () =>
  typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

function readAll() {
  try {
    const raw = localStorage.getItem(KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

function writeAll(list) {
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
  } catch {
    throw new Error('Could not save data. Browser storage may be full or disabled.');
  }
}

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function normalize(input) {
  const data = {
    name: String(input.name || '').trim(),
    dosage: String(input.dosage || '').trim(),
    times: Array.isArray(input.times) ? [...new Set(input.times.map(String))].sort() : [],
    startDate: String(input.startDate || ''),
    endDate: String(input.endDate || ''),
    notes: String(input.notes || '').trim(),
  };
  if (!data.name) throw new Error('Medicine name is required');
  if (!data.dosage) throw new Error('Dosage is required');
  if (data.times.length === 0) throw new Error('At least one time is required');
  if (!data.times.every((t) => TIME_RE.test(t))) throw new Error('Times must be valid');
  if (!DATE_RE.test(data.startDate) || !DATE_RE.test(data.endDate)) {
    throw new Error('Start and end dates are required');
  }
  if (data.endDate < data.startDate) throw new Error('End date cannot be before start date');
  return data;
}

export function getMedicines() {
  return readAll().sort((a, b) => b.startDate.localeCompare(a.startDate));
}

export function getMedicine(id) {
  return readAll().find((m) => m._id === id) || null;
}

export function createMedicine(input) {
  const med = { ...normalize(input), _id: newId(), takenLog: [], createdAt: Date.now() };
  writeAll([...readAll(), med]);
  return med;
}

export function updateMedicine(id, input) {
  const list = readAll();
  const idx = list.findIndex((m) => m._id === id);
  if (idx < 0) throw new Error('Medicine not found');
  const updated = { ...list[idx], ...normalize(input) };
  list[idx] = updated;
  writeAll(list);
  return updated;
}

export function deleteMedicine(id) {
  writeAll(readAll().filter((m) => m._id !== id));
}

// Toggle a dose as taken / not taken for a given date and time
export function toggleTaken(id, date, time) {
  const list = readAll();
  const idx = list.findIndex((m) => m._id === id);
  if (idx < 0) throw new Error('Medicine not found');
  const log = list[idx].takenLog || [];
  const has = log.some((l) => l.date === date && l.time === time);
  list[idx] = {
    ...list[idx],
    takenLog: has ? log.filter((l) => !(l.date === date && l.time === time)) : [...log, { date, time }],
  };
  writeAll(list);
  return list[idx];
}
